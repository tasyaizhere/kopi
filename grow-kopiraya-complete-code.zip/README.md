# Grow@KopiRaya

LMS pelatihan pegawai Kopi Raya berbasis HTML/CSS/JavaScript Vanilla, Supabase, dan Netlify.

## Menjalankan lokal

1. Pastikan `js/config.js` memakai Supabase URL dan anon/publishable key yang benar.
2. Jalankan static server pada root proyek (misalnya `npx serve .`).
3. Buka `index.html` atau `login.html`.

## Aktivasi backend

Jalankan migration berurutan pada project Supabase yang sama:

1. `supabase/migrations/001_initial_schema.sql`
2. `supabase/migrations/002_lms_workflows.sql`
3. `supabase/migrations/003_storage_setup.sql`

Atur environment variables Netlify `SUPABASE_URL`, `SUPABASE_ANON_KEY`, dan `SUPABASE_SERVICE_ROLE_KEY`. Service role key hanya boleh disimpan sebagai environment variable server-side Netlify. Jangan pernah memasukkannya ke `js/config.js`.

Setelah konfigurasi, deploy ulang Netlify agar Functions `create-user` dan `update-user` aktif.

## Pengujian

```bash
npm test
```

Lihat `docs/STATUS-PENYELESAIAN-FITUR.md` untuk cakupan fitur, aturan level, konflik dokumen sumber, dan status verifikasi.
