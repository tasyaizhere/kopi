export const PASSING_SCORE_DEFAULT = 70;
export function isPracticePeriodComplete(startDate, today = new Date()) {
  if (!startDate) return false;
  const start = new Date(`${startDate}T00:00:00Z`);
  const end = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate()));
  if (Number.isNaN(start.getTime())) return false;
  return Math.floor((end - start) / 86400000) >= 14;
}
export function latestAttempt(attempts = []) {
  return [...attempts].sort((a,b) => (b.percobaan_ke ?? 0) - (a.percobaan_ke ?? 0))[0] ?? null;
}
export function officialScore(attempts = []) { return latestAttempt(attempts)?.nilai ?? null; }
export function canOpenLevel2({allRequiredLevel1MaterialsComplete, latestLevel1Attempts, practiceStartDate, today, ownerApproved}) {
  const attempts = latestLevel1Attempts ?? [];
  return Boolean(allRequiredLevel1MaterialsComplete && attempts.length > 0 && attempts.every(a => a.status_kelulusan === true) && isPracticePeriodComplete(practiceStartDate,today) && ownerApproved === true);
}
