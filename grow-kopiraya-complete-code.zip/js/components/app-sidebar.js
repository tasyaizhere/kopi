
import "./brand-logo.js";

class AppSidebar extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: "open" });
  }

  connectedCallback() {
    this.render();
  }

  get menuConfig() {
    return {
      owner: [
        { label: "Dashboard", href: "/pages/owner/dashboard.html", available: true, icon: "", page: "dashboard.html" },
        { label: "Daftar Pegawai", href: "/pages/owner/pegawai.html", available: true, icon: "", page: "pegawai.html" },
        { label: "Manajemen Akun", href: "/pages/owner/akun.html", available: true, icon: "", page: "akun.html" },
        { label: "Kelola Materi", href: "/pages/owner/materi.html", available: true, icon: "", page: "materi.html" },
        { label: "Kelola Kuis", href: "/pages/owner/kuis.html", available: true, icon: "", page: "kuis.html" },
        { label: "Evaluasi Praktik", href: "/pages/owner/evaluasi.html", available: true, icon: "", page: "evaluasi.html" },
        { label: "Laporan", href: "/pages/owner/laporan.html", available: true, icon: "", page: "laporan.html" }
      ],

      admin: [
        { label: "Dashboard", href: "/pages/admin/dashboard.html", available: true, icon: "", page: "dashboard.html" },
        { label: "Manajemen Pengguna", href: "/pages/admin/pengguna.html", available: true, icon: "", page: "pengguna.html" }
      ],

      pegawai: [
        { label: "Dashboard", href: "/pages/pegawai/dashboard.html", available: true, icon: "", page: "dashboard.html" },
        { label: "Materi Pembelajaran", href: "/pages/pegawai/materi.html", available: true, icon: "", page: "materi.html" },
        { label: "Kuis", href: "/pages/pegawai/kuis.html", available: true, icon: "", page: "kuis.html" },
        { label: "Progres Belajar", href: "/pages/pegawai/progres.html", available: true, icon: "", page: "progres.html" },
        { label: "Nilai & Riwayat", href: "/pages/pegawai/riwayat.html", available: true, icon: "", page: "riwayat.html" },
        { label: "Evaluasi", href: "/pages/pegawai/evaluasi.html", available: true, icon: "", page: "evaluasi.html" }
      ]
    };
  }

  render() {
    const userRole = this.getAttribute("user-role");
    const activePage =
      this.getAttribute("active-page") ||
      window.location.pathname.split("/").pop();

    const menus = this.menuConfig[userRole];

    if (!menus) {
      console.error("AppSidebar: user-role tidak valid.");
      this.shadowRoot.innerHTML = "";
      return;
    }

    const menuHTML = menus.map((item) => {
      const isActive = item.page === activePage;

      if (!item.available) {
        return `
          <span class="nav-link unavailable" aria-disabled="true" title="Modul belum tersedia pada versi proyek ini">
            <span class="nav-icon" aria-hidden="true">${item.icon}</span>
            <span>${item.label}</span>
            <small>Segera</small>
          </span>
        `;
      }

      return `
        <a
          class="nav-link ${isActive ? "active" : ""}"
          href="${item.href}"
          ${isActive ? 'aria-current="page"' : ""}
        >
          <span class="nav-icon" aria-hidden="true">${item.icon}</span>
          <span>${item.label}</span>
        </a>
      `;
    }).join("");

    this.shadowRoot.innerHTML = `
      <style>
        :host {
          display: block;
          min-width: 0;
        }

        * {
          box-sizing: border-box;
        }

        .sidebar {
          min-height: 100vh;
          height: 100%;
          padding: 26px 18px;
          background: linear-gradient(180deg, #f4e9dd 0%, #ead9c6 100%);
          border-right: 1px solid #e7d9cc;
          box-shadow: 8px 0 28px rgba(57,39,30,.035);
          display: flex;
          flex-direction: column;
        }

        .brand {
          display: flex;
          align-items: center;
          gap: 11px;
          padding: 4px 8px;
          margin-bottom: 30px;
          color: #70472f;
          font-size: 1.02rem;
          font-weight: 800;
          letter-spacing: -.02em;
          text-decoration: none;
        }

        .brand-name b {
          color: #b98255;
        }

        nav {
          display: grid;
          gap: 7px;
        }

        .nav-link {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 12px 13px;
          border-radius: 12px;
          color: #70472f;
          text-decoration: none;
          font-family: inherit;
          font-size: .92rem;
          font-weight: 600;
          transition: background .2s ease;
        }

        .nav-link:hover,
        .nav-link.active {
          background: #fffdfa;
          box-shadow: 0 4px 14px rgba(57,39,30,.055);
        }

        .nav-link.active {
          font-weight: 800;
        }

        .nav-link.unavailable {
          color: #9b8879;
          cursor: not-allowed;
          opacity: .78;
        }

        .nav-link.unavailable small {
          margin-left: auto;
          font-size: .62rem;
          font-weight: 700;
          letter-spacing: .02em;
          color: #9a6a42;
        }

        .nav-icon {
          width: 22px;
          text-align: center;
          font-size: 1.1rem;
          flex-shrink: 0;
        }

        .sidebar-footer {
          margin-top: auto;
          padding: 20px 8px 0;
          color: #8b786b;
          font-size: .75rem;
        }

        @media (max-width: 900px) {
          .sidebar {
            min-height: auto;
            height: auto;
            padding: 14px;
            border-right: 0;
            border-bottom: 1px solid #e7d9cc;
          }

          nav {
            display: flex;
            overflow-x: auto;
            gap: 7px;
            padding-bottom: 4px;
          }

          .nav-link {
            white-space: nowrap;
            flex-shrink: 0;
          }

          .sidebar-footer {
            display: none;
          }
        }
      </style>

      <aside class="sidebar">
        <a class="brand" href="/index.html">
          <brand-logo size="42"></brand-logo>
          <span class="brand-name">Grow<b>@</b>KopiRaya</span>
        </a>

        <nav aria-label="Navigasi utama">
          ${menuHTML}
        </nav>

        <div class="sidebar-footer">
          Kopi Raya • Learning System
        </div>
      </aside>
    `;
  }
}

customElements.define("app-sidebar", AppSidebar);
