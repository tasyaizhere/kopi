
class BrandLogo extends HTMLElement {
  connectedCallback() {
    if (this.shadowRoot) return;

    const size = this.getAttribute("size") || "48";

    this.attachShadow({ mode: "open" });

    this.shadowRoot.innerHTML = `
      <style>
        :host {
          display: inline-flex;
          width: ${size}px;
          height: ${size}px;
          flex-shrink: 0;
          vertical-align: middle;
        }

        .logo {
          width: 100%;
          height: 100%;
          display: flex;
          align-items: center;
          justify-content: center;
          overflow: hidden;
          border-radius: 50%;
          background: #ffffff;
        }

        img {
          width: 100%;
          height: 100%;
          object-fit: contain;
          display: block;
        }
      </style>

      <div class="logo">
        <img
          src="/assets/images/logo-kopi-raya.png"
          alt="Logo Kopi Raya"
        >
      </div>
    `;
  }
}

// Daftarkan komponen satu kali
if (!customElements.get("brand-logo")) {
  customElements.define("brand-logo", BrandLogo);
}

// Gunakan gambar yang sama sebagai favicon
const favicon = document.querySelector('link[rel="icon"]')
  || document.createElement("link");

favicon.rel = "icon";
favicon.type = "image/png";
favicon.href = "/assets/images/logo-kopi-raya.png";

if (!favicon.isConnected) {
  document.head.appendChild(favicon);
}
