import { supabase } from './supabase.js';

export async function requireRole(expectedRole) {
    if (!supabase) {
        location.replace('/');
        throw new Error('Konfigurasi Supabase belum tersedia.');
    }

    const {
        data: { user },
        error: authError
    } = await supabase.auth.getUser();

    if (authError || !user) {
        location.replace('/');
        throw new Error('Sesi login tidak valid.');
    }

    const {
        data: profile,
        error: profileError
    } = await supabase
        .from('users')
        .select('id, nama, email, role, status_akun')
        .eq('auth_user_id', user.id)
        .maybeSingle();

    if (
        profileError ||
        !profile ||
        profile.status_akun !== 'aktif' ||
        profile.role !== expectedRole
    ) {
        await supabase.auth.signOut();
        location.replace('/');
        throw new Error('Akses ditolak.');
    }

    return profile;
}