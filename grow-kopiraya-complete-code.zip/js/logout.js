
import { supabase } from './supabase.js';

const logoutButton = document.querySelector('#logout');

if (logoutButton) {
    logoutButton.addEventListener('click', async (event) => {
        event.preventDefault();

        try {
            if (supabase) {
                const { error } = await supabase.auth.signOut();

                if (error) {
                    throw error;
                }
            }

            location.href = '/login.html';

        } catch (error) {
            console.error('Logout gagal:', error);
            alert('Gagal keluar dari akun. Silakan coba lagi.');
        }
    });
}
