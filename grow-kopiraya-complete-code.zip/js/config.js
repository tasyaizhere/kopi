
export const SUPABASE_URL = 'https://tocgmlypkumfppvuayol.supabase.co';
export const SUPABASE_ANON_KEY = 'sb_publishable_T3Nes2iAWbgRSFdVrqZPhQ_AO7Yj5Wu';

export const configured = Boolean(
  SUPABASE_URL && SUPABASE_ANON_KEY
);
