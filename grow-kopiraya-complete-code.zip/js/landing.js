(() => {
  const showcase = document.querySelector('.product-showcase');
  if (!showcase) return;

  const products = [
    { name: 'Kopi Raya Arabica', label: 'ARABICA', className: 'arabica', description: 'Kenali varian produk Kopi Raya melalui koleksi visual ini.' },
    { name: 'Kopi Raya Blend', label: 'BLEND', className: 'blend', description: 'Kenali varian produk Kopi Raya melalui koleksi visual ini.' },
    { name: 'Kopi Raya Americano', label: 'AMERICANO', className: 'americano', description: 'Kenali varian produk Kopi Raya melalui koleksi visual ini.' }
  ];

  const pouch = showcase.querySelector('[data-product-pouch]');
  const title = showcase.querySelector('[data-product-title]');
  const description = showcase.querySelector('[data-product-description]');
  const index = showcase.querySelector('[data-showcase-index]');
  const buttons = [...showcase.querySelectorAll('[data-variant]')];
  let active = 0;
  let changeTimer;

  function selectProduct(nextIndex) {
    if (!Number.isInteger(nextIndex) || nextIndex < 0 || nextIndex >= products.length || nextIndex === active) return;
    const product = products[nextIndex];
    showcase.classList.add('is-changing');
    window.clearTimeout(changeTimer);
    changeTimer = window.setTimeout(() => {
      active = nextIndex;
      pouch.className = `coffee-pouch ${product.className}`;
      pouch.querySelector('.pouch-variant').textContent = product.label;
      title.textContent = product.name;
      description.textContent = product.description;
      index.textContent = `0${nextIndex + 1} / 03`;
      buttons.forEach((button, i) => {
        const selected = i === nextIndex;
        button.classList.toggle('active', selected);
        button.setAttribute('aria-pressed', String(selected));
      });
      showcase.classList.remove('is-changing');
    }, 180);
  }

  buttons.forEach((button) => {
    button.addEventListener('click', () => selectProduct(Number(button.dataset.variant)));
  });

  const toggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('#primary-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      const open = toggle.getAttribute('aria-expanded') !== 'true';
      toggle.setAttribute('aria-expanded', String(open));
      toggle.setAttribute('aria-label', open ? 'Tutup navigasi' : 'Buka navigasi');
      nav.classList.toggle('is-open', open);
    });
    nav.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => {
      toggle.setAttribute('aria-expanded', 'false');
      toggle.setAttribute('aria-label', 'Buka navigasi');
      nav.classList.remove('is-open');
    }));
  }
})();
