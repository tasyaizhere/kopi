import { supabase } from '../supabase.js';

export const $ = (selector, root = document) => root.querySelector(selector);
export const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
export const escapeHTML = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const formatDate = value => value ? new Intl.DateTimeFormat('id-ID',{dateStyle:'medium'}).format(new Date(value)) : '—';
export const formatScore = value => value == null ? '—' : `${Number(value).toFixed(1).replace(/\.0$/,'')} / 100`;
export function notice(target, message, kind = 'info') { if (!target) return; target.textContent = message; target.dataset.kind = kind; }
export function fail(error, target) { console.error(error); notice(target, error?.message || 'Terjadi kesalahan. Silakan coba kembali.', 'error'); }
export async function session(role) {
  if (!supabase) throw new Error('Konfigurasi Supabase belum tersedia.');
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error || !user) { location.replace('/'); throw new Error('Sesi login tidak valid.'); }
  const { data: profile, error: profileError } = await supabase.from('users').select('id,nama,email,role,status_akun').eq('auth_user_id',user.id).maybeSingle();
  if (profileError || !profile || profile.status_akun !== 'aktif' || (role && profile.role !== role)) {
    await supabase.auth.signOut(); location.replace('/'); throw new Error('Akses ditolak atau akun tidak aktif.');
  }
  const name = $('[data-user-name]'); if (name) name.textContent = profile.nama;
  return { user, profile, supabase };
}
export async function functionRequest(path, body, method='POST') {
  const { data: { session: active } } = await supabase.auth.getSession();
  if (!active?.access_token) throw new Error('Sesi login telah berakhir. Silakan masuk kembali.');
  const response = await fetch(`/.netlify/functions/${path}`, { method, headers: {'Content-Type':'application/json','Authorization':`Bearer ${active.access_token}`}, ...(body ? {body:JSON.stringify(body)} : {}) });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(result.error || `Permintaan gagal (${response.status}).`);
  return result;
}
export function setBusy(button, busy, label='Memproses…') { if (!button) return; if (busy) { button.dataset.oldLabel = button.textContent; button.textContent = label; button.disabled = true; } else { button.textContent = button.dataset.oldLabel || button.textContent; button.disabled = false; } }
