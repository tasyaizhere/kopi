import { session, $, escapeHTML, notice, fail, setBusy } from './app.js';
let sb, profile, items=[];
async function load(){
 const {data,error}=await sb.from('materi').select('id,judul,deskripsi,isi_materi,level,file_path,wajib,status_publikasi,created_at').order('created_at',{ascending:false});
 if(error)throw error;items=data||[];
 $('#material-total').textContent=items.length;$('#material-published').textContent=items.filter(x=>x.status_publikasi==='publikasi').length;$('#material-draft').textContent=items.filter(x=>x.status_publikasi==='draft').length;render();
}
function render(){
 const q=$('#material-search').value.toLowerCase(),level=$('#material-filter').value;
 const data=items.filter(x=>(!q||x.judul.toLowerCase().includes(q))&&(!level||String(x.level)===level));
 $('#material-list').innerHTML=data.length?data.map(x=>`<tr><td><strong>${escapeHTML(x.judul)}</strong><br><small class="muted">${escapeHTML(x.deskripsi||'')}</small></td><td>Level ${x.level}</td><td>${x.wajib?'Ya':'Tidak'}</td><td><span class="pill">${x.status_publikasi}</span></td><td>${x.file_path?'Tersedia':'—'}</td><td><button class="btn logout" data-edit="${x.id}">Edit</button> <button class="btn logout" data-delete="${x.id}">Hapus/arsip</button></td></tr>`).join(''):'<tr><td colspan="6" class="empty">Belum ada materi.</td></tr>';
}
function reset(){ $('#material-form').reset();$('#material-id').value='';$('#material-required').checked=true;$('#material-editor-title').textContent='Tambah materi'; }
async function handleListClick(e){
 try{
  const edit=e.target.closest('[data-edit]'),del=e.target.closest('[data-delete]');
  if(edit){const x=items.find(m=>m.id===edit.dataset.edit);$('#material-id').value=x.id;$('#material-title').value=x.judul;$('#material-description').value=x.deskripsi||'';$('#material-content').value=x.isi_materi||'';$('#material-level').value=x.level;$('#material-status').value=x.status_publikasi;$('#material-required').checked=x.wajib;$('#material-editor-title').textContent='Edit materi';$('#material-form').scrollIntoView({behavior:'smooth'});}
  if(del&&confirm('Materi dengan riwayat progres akan diarsipkan, bukan dihapus permanen. Lanjutkan?')){
   const x=items.find(m=>m.id===del.dataset.delete);const {count,error}=await sb.from('progres_materi').select('*',{count:'exact',head:true}).eq('materi_id',x.id);if(error)throw error;
   if(count>0){const result=await sb.from('materi').update({status_publikasi:'arsip',updated_at:new Date().toISOString()}).eq('id',x.id);if(result.error)throw result.error;notice($('#material-message'),'Materi memiliki riwayat belajar, sehingga diarsipkan.','success');}
   else{const result=await sb.from('materi').delete().eq('id',x.id);if(result.error)throw result.error;if(x.file_path){const removed=await sb.storage.from('materi-pdf').remove([x.file_path]);if(removed.error)console.warn('File lama tidak terhapus:',removed.error);}notice($('#material-message'),'Materi dihapus.','success');}
   await load();
  }
 }catch(err){fail(err,$('#material-message'));}
}
async function saveMaterial(e){
 e.preventDefault();const btn=$('#save-material');setBusy(btn,true);let uploadedPath=null;
 try{
  const id=$('#material-id').value||null;let filePath=items.find(x=>x.id===id)?.file_path||null;const oldFilePath=filePath;const file=$('#material-file').files[0];
  if(file){if(file.type!=='application/pdf'||file.size>15*1024*1024)throw new Error('File harus PDF dan berukuran maksimal 15 MB.');const safe=file.name.replace(/[^a-zA-Z0-9._-]/g,'-');uploadedPath=`${profile.id}/${crypto.randomUUID()}-${safe}`;const {error}=await sb.storage.from('materi-pdf').upload(uploadedPath,file,{contentType:'application/pdf',upsert:false});if(error)throw error;filePath=uploadedPath;}
  const values={judul:$('#material-title').value.trim(),deskripsi:$('#material-description').value.trim(),isi_materi:$('#material-content').value.trim(),level:Number($('#material-level').value),file_path:filePath,wajib:$('#material-required').checked,status_publikasi:$('#material-status').value,updated_at:new Date().toISOString()};
  const result=id?await sb.from('materi').update(values).eq('id',id):await sb.from('materi').insert({...values,created_by:profile.id});if(result.error)throw result.error;
  if(oldFilePath&&oldFilePath!==filePath){const removed=await sb.storage.from('materi-pdf').remove([oldFilePath]);if(removed.error)console.warn('File lama tidak terhapus:',removed.error);}uploadedPath=null;
  notice($('#material-message'),'Materi berhasil disimpan.','success');reset();await load();
 }catch(err){if(uploadedPath)await sb.storage.from('materi-pdf').remove([uploadedPath]);fail(err,$('#material-message'));}
 finally{setBusy(btn,false);}
}
async function start(){try{({supabase:sb,profile}=await session('owner'));await load();$('#material-search').addEventListener('input',render);$('#material-filter').addEventListener('change',render);$('#reset-material').addEventListener('click',reset);$('#material-list').addEventListener('click',handleListClick);$('#material-form').addEventListener('submit',saveMaterial);}catch(err){fail(err,$('#material-message'));}}
start();
