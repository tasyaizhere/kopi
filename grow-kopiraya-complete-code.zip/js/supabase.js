import {
    SUPABASE_URL,
    SUPABASE_ANON_KEY,
    configured
} from './config.js';

import {
    createClient
} from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm';

export const supabase = configured
    ? createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
    : null;