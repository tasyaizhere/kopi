
import {
  SUPABASE_URL,
  SUPABASE_ANON_KEY,
  configured
} from './config.js';

const tbody = document.querySelector('#pegawai-list');
const searchInput = document.querySelector('#search-pegawai');
const statusFilter = document.querySelector('#filter-status');
const message = document.querySelector('#message');

let pegawaiData = [];

function escapeHTML(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  })[char]);
}

function tampilkanStatistik(data) {
  document.querySelector('#total-pegawai').textContent = data.length;

  document.querySelector('#pegawai-aktif').textContent =
    data.filter(p => p.status_akun === 'aktif').length;

  document.querySelector('#pegawai-nonaktif').textContent =
    data.filter(p => p.status_akun === 'nonaktif').length;
}

function tampilkanPegawai(data) {
  if (!data.length) {
    tbody.innerHTML = `
      <tr>
        <td colspan="4" class="empty">
          Tidak ada data pegawai yang ditemukan.
        </td>
      </tr>
    `;
    return;
  }

  tbody.innerHTML = data.map((pegawai, index) => `
    <tr>
      <td>${index + 1}</td>
      <td>${escapeHTML(pegawai.nama)}</td>
      <td>${escapeHTML(pegawai.email)}</td>
      <td>
        <span class="pill">
          ${escapeHTML(pegawai.status_akun)}
        </span>
      </td>
    </tr>
  `).join('');
}

function filterPegawai() {
  const keyword = searchInput.value.toLowerCase().trim();
  const status = statusFilter.value;

  const hasil = pegawaiData.filter(pegawai => {
    const cocokNama = pegawai.nama.toLowerCase().includes(keyword);
    const cocokEmail = pegawai.email.toLowerCase().includes(keyword);
    const cocokStatus = !status || pegawai.status_akun === status;

    return (cocokNama || cocokEmail) && cocokStatus;
  });

  tampilkanPegawai(hasil);
}

async function mulai() {
  if (!configured) {
    message.textContent = 'Konfigurasi Supabase belum tersedia.';
    return;
  }

  try {
    const { createClient } = await import(
      'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm'
    );

    const sb = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

    const { data: { user }, error: authError } =
      await sb.auth.getUser();

    if (authError || !user) {
      location.href = '/';
      return;
    }

    const { data: profil, error: profilError } = await sb
      .from('users')
      .select('id, nama, role, status_akun')
      .eq('auth_user_id', user.id)
      .single();

    if (
      profilError ||
      !profil ||
      profil.role !== 'owner' ||
      profil.status_akun !== 'aktif'
    ) {
      location.href = '/';
      return;
    }

    const { data, error } = await sb
      .from('users')
      .select('nama, email, status_akun')
      .eq('role', 'pegawai')
      .order('nama', { ascending: true });

    if (error) throw error;

    pegawaiData = data || [];

    tampilkanStatistik(pegawaiData);
    tampilkanPegawai(pegawaiData);

    searchInput.addEventListener('input', filterPegawai);
    statusFilter.addEventListener('change', filterPegawai);

  } catch (error) {
    console.error('Gagal memuat pegawai:', error);
    message.textContent =
      'Gagal mengambil data pegawai. Periksa koneksi dan kebijakan database.';
  }
}

mulai();
