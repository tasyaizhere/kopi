import { requireRole } from './auth.js';
import { supabase } from './supabase.js';
const role=document.body.dataset.role;
const name=document.querySelector('[data-user-name]');
try{
 const profile=await requireRole(role);if(name)name.textContent=profile.nama;
 if(role==='owner'){
  const [{count:people,error:a},{count:materials,error:b},{data:results,error:c}]=await Promise.all([supabase.from('users').select('*',{count:'exact',head:true}).eq('role','pegawai'),supabase.from('materi').select('*',{count:'exact',head:true}).eq('status_publikasi','publikasi'),supabase.from('hasil_kuis').select('pegawai_id,kuis_id,percobaan_ke,nilai').order('percobaan_ke',{ascending:false})]);if(a||b||c)throw a||b||c;
  const latest=new Map();(results||[]).forEach(x=>{const key=`${x.pegawai_id}:${x.kuis_id}`;if(!latest.has(key)||x.percobaan_ke>latest.get(key).percobaan_ke)latest.set(key,x);});const scores=[...latest.values()].map(x=>Number(x.nilai));document.querySelector('#total').textContent=people??0;document.querySelector('#materials').textContent=materials??0;document.querySelector('#average').textContent=scores.length?(scores.reduce((x,y)=>x+y,0)/scores.length).toFixed(1):'—';
 }else if(role==='admin'){
  const [{count:accounts,error:a},{count:employees,error:b},{count:admins,error:c}]=await Promise.all([supabase.from('users').select('*',{count:'exact',head:true}),supabase.from('users').select('*',{count:'exact',head:true}).eq('role','pegawai'),supabase.from('users').select('*',{count:'exact',head:true}).eq('role','admin')]);if(a||b||c)throw a||b||c;document.querySelector('#accounts').textContent=accounts??0;document.querySelector('#employees').textContent=employees??0;document.querySelector('#admins').textContent=admins??0;
 }else if(role==='pegawai'){
  const [{data:levels,error:a},{count:done,error:b},{data:score,error:c}]=await Promise.all([supabase.from('riwayat_level').select('level_baru').eq('pegawai_id',profile.id).order('tanggal_perubahan',{ascending:false}).limit(1),supabase.from('progres_materi').select('*',{count:'exact',head:true}).eq('pegawai_id',profile.id).eq('status','selesai'),supabase.from('hasil_kuis').select('nilai').eq('pegawai_id',profile.id).order('tanggal_selesai',{ascending:false}).limit(1)]);if(a||b||c)throw a||b||c;document.querySelector('#level').textContent=`Level ${levels?.[0]?.level_baru||1}`;document.querySelector('#progress').textContent=`${done??0} materi`;document.querySelector('#score').textContent=score?.[0]?.nilai==null?'—':`${score[0].nilai}`;
 }
}catch(error){console.error('Pemeriksaan akses/dashboard gagal:',error);const target=document.querySelector('.main');if(target){const p=document.createElement('p');p.className='message';p.textContent=error.message||'Data dashboard gagal dimuat.';target.prepend(p);}}
