Halaman dashboard Owner awal. Halaman CRUD materi, kuis, evaluasi, jadwal, dan laporan akan diimplementasikan pada increment berikutnya.
