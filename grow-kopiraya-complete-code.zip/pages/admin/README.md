Halaman dashboard Admin awal. Admin hanya mengelola akun pengguna; tidak memiliki akses ke modul pembelajaran.
