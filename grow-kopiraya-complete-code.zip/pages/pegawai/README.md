Halaman dashboard Pegawai awal. Pegawai hanya dapat mengakses pembelajaran dan data pribadinya.
