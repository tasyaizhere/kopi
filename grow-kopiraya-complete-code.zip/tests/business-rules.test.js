import test from 'node:test';
import assert from 'node:assert/strict';
import {isPracticePeriodComplete,latestAttempt,officialScore,canOpenLevel2} from '../js/business-rules.js';
test('praktik tepat 14 hari kalender memenuhi durasi',()=>assert.equal(isPracticePeriodComplete('2026-01-01',new Date('2026-01-15T00:00:00Z')),true));
test('praktik 13 hari belum memenuhi durasi',()=>assert.equal(isPracticePeriodComplete('2026-01-01',new Date('2026-01-14T00:00:00Z')),false));
test('nilai resmi adalah nilai percobaan terakhir',()=>assert.equal(officialScore([{percobaan_ke:1,nilai:80},{percobaan_ke:2,nilai:72}]),72));
test('latestAttempt mengembalikan percobaan bernomor tertinggi',()=>assert.equal(latestAttempt([{percobaan_ke:2},{percobaan_ke:1}]).percobaan_ke,2));
test('Level 2 hanya terbuka jika seluruh persyaratan terpenuhi',()=>assert.equal(canOpenLevel2({allRequiredLevel1MaterialsComplete:true,latestLevel1Attempts:[{status_kelulusan:true}],practiceStartDate:'2026-01-01',today:new Date('2026-01-15T00:00:00Z'),ownerApproved:true}),true));
test('Level 2 tetap terkunci jika Owner belum menyetujui',()=>assert.equal(canOpenLevel2({allRequiredLevel1MaterialsComplete:true,latestLevel1Attempts:[{status_kelulusan:true}],practiceStartDate:'2026-01-01',today:new Date('2026-01-15T00:00:00Z'),ownerApproved:false}),false));
