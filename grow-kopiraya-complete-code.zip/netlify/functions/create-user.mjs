
import { createClient } from '@supabase/supabase-js';

export default async (req) => {
    if (req.method !== 'POST') {
        return Response.json(
            { error: 'Method tidak diizinkan.' },
            { status: 405 }
        );
    }

    const url = process.env.SUPABASE_URL;
    const anon = process.env.SUPABASE_ANON_KEY;
    const service = process.env.SUPABASE_SERVICE_ROLE_KEY;

    if (!url || !anon || !service) {
        return Response.json(
            { error: 'Konfigurasi server belum lengkap.' },
            { status: 500 }
        );
    }

    try {
        const token = (req.headers.get('authorization') || '')
            .replace(/^Bearer\s+/i, '');

        if (!token) {
            return Response.json(
                { error: 'Autentikasi diperlukan.' },
                { status: 401 }
            );
        }

        // Memverifikasi identitas pengguna yang sedang login.
        const userClient = createClient(url, anon, {
            global: {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            }
        });

        const {
            data: { user },
            error: authError
        } = await userClient.auth.getUser();

        if (authError || !user) {
            return Response.json(
                { error: 'Sesi login tidak valid.' },
                { status: 401 }
            );
        }

        // Memeriksa role dan status akun pembuat.
        const { data: actor, error: actorError } = await userClient
            .from('users')
            .select('id, role, status_akun')
            .eq('auth_user_id', user.id)
            .maybeSingle();

        if (
            actorError ||
            !actor ||
            actor.status_akun !== 'aktif'
        ) {
            return Response.json(
                { error: 'Akun tidak memiliki izin.' },
                { status: 403 }
            );
        }

        // Membaca data akun baru.
        const body = await req.json();

        const nama = typeof body.nama === 'string'
            ? body.nama.trim()
            : '';

        const email = typeof body.email === 'string'
            ? body.email.trim().toLowerCase()
            : '';

        const password = typeof body.password === 'string'
            ? body.password
            : '';

        const role = body.role;

        if (!nama || nama.length > 120) {
            return Response.json(
                { error: 'Nama wajib diisi (maksimal 120 karakter).' },
                { status: 400 }
            );
        }

        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            return Response.json(
                { error: 'Format email tidak valid.' },
                { status: 400 }
            );
        }

        if (password.length < 8 || password.length > 72) {
            return Response.json(
                { error: 'Password harus terdiri dari 8–72 karakter.' },
                { status: 400 }
            );
        }

        // Aturan kewenangan pembuatan akun.
        const allowedRoles = {
            owner: ['admin'],
            admin: ['pegawai']
        };

        if (
            !allowedRoles[actor.role] ||
            !allowedRoles[actor.role].includes(role)
        ) {
            return Response.json(
                { error: 'Kamu tidak memiliki izin membuat role tersebut.' },
                { status: 403 }
            );
        }

        // Service role hanya digunakan di backend.
        const adminClient = createClient(url, service);

        const {
            data: created,
            error: createError
        } = await adminClient.auth.admin.createUser({
            email,
            password,
            email_confirm: true
        });

        if (createError) {
            return Response.json(
                { error: createError.message },
                { status: 400 }
            );
        }

        // Menyimpan profil akun ke tabel public.users.
        const { error: profileError } = await adminClient
            .from('users')
            .insert({
                auth_user_id: created.user.id,
                nama,
                email,
                role,
                status_akun: 'aktif'
            });

        // Membatalkan akun Auth jika profil gagal disimpan.
        if (profileError) {
            const { error: rollbackError } =
                await adminClient.auth.admin.deleteUser(
                    created.user.id
                );

            if (rollbackError) {
                console.error(
                    'Rollback akun Auth gagal:',
                    rollbackError
                );
            }

            return Response.json(
                { error: 'Profil gagal dibuat. Proses dibatalkan.' },
                { status: 500 }
            );
        }

        return Response.json(
            {
                message: 'Akun berhasil dibuat.',
                user_id: created.user.id,
                role
            },
            { status: 201 }
        );

    } catch (error) {
        console.error('Create user error:', error);

        return Response.json(
            { error: 'Terjadi kesalahan pada server.' },
            { status: 500 }
        );
    }
};
