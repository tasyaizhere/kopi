import { createClient } from '@supabase/supabase-js';
export default async req => {
  if (req.method !== 'POST') return Response.json({error:'Method tidak diizinkan.'},{status:405});
  const {SUPABASE_URL:url,SUPABASE_ANON_KEY:anon,SUPABASE_SERVICE_ROLE_KEY:service}=process.env;
  if(!url||!anon||!service)return Response.json({error:'Konfigurasi server belum lengkap.'},{status:500});
  try{
    const token=(req.headers.get('authorization')||'').replace(/^Bearer\s+/i,'');if(!token)return Response.json({error:'Autentikasi diperlukan.'},{status:401});
    const userClient=createClient(url,anon,{global:{headers:{Authorization:`Bearer ${token}`}}});
    const {data:{user},error:authError}=await userClient.auth.getUser();if(authError||!user)return Response.json({error:'Sesi tidak valid.'},{status:401});
    const {data:actor,error:actorError}=await userClient.from('users').select('id,role,status_akun').eq('auth_user_id',user.id).maybeSingle();
    if(actorError||!actor||actor.status_akun!=='aktif')return Response.json({error:'Akun tidak memiliki izin.'},{status:403});
    const body=await req.json();const targetId=String(body.user_id||'');const nama=String(body.nama||'').trim();const email=String(body.email||'').trim().toLowerCase();const status=body.status_akun;
    if(!targetId||!nama||nama.length>120||!/^\S+@\S+\.\S+$/.test(email)||!['aktif','nonaktif'].includes(status))return Response.json({error:'Data pengguna tidak valid.'},{status:400});
    const admin=createClient(url,service);const {data:target,error:targetError}=await admin.from('users').select('id,role,auth_user_id,email,status_akun').eq('id',targetId).maybeSingle();
    const allowed=actor.role==='admin'?target?.role==='pegawai':actor.role==='owner'?target?.role==='admin':false;
    if(targetError||!target||!allowed)return Response.json({error:'Kamu tidak berhak mengubah akun ini.'},{status:403});
    const {error:updateAuth}=await admin.auth.admin.updateUserById(target.auth_user_id,{email,email_confirm:true,ban_duration:status==='nonaktif'?'876000h':'none'});if(updateAuth)return Response.json({error:updateAuth.message},{status:400});
    const {error:updateProfile}=await admin.from('users').update({nama,email,status_akun:status,updated_at:new Date().toISOString()}).eq('id',targetId);
    if(updateProfile){await admin.auth.admin.updateUserById(target.auth_user_id,{email:target.email,email_confirm:true,ban_duration:target.status_akun==='nonaktif'?'876000h':'none'});return Response.json({error:'Profil gagal diperbarui. Perubahan Auth dibatalkan.'},{status:500});}
    return Response.json({message:'Akun berhasil diperbarui.'});
  }catch(error){console.error('Update user error:',error);return Response.json({error:'Terjadi kesalahan server.'},{status:500});}
};
