# Catatan Status Konstruksi — Increment 01

## Sudah dibuat
- Halaman login frontend dengan Supabase Auth integration point.
- Dashboard awal yang dibedakan untuk Owner, Admin, dan Pegawai.
- Struktur folder proyek.
- Baseline 11 tabel PostgreSQL dan beberapa RLS policies.
- Pemisahan tabel kunci jawaban dari tabel soal.
- Contoh Netlify Function pembuatan akun oleh Admin.
- Aturan bisnis inti dalam helper JavaScript dan unit tests.
- README, konfigurasi Netlify, contoh environment, dan test plan.
- Salinan kedua dokumen sumber pada `docs/referensi/`.

## Belum selesai
- Seluruh halaman CRUD dan seluruh modul bisnis.
- RPC/endpoint submit kuis lengkap yang melakukan penilaian atomik.
- Endpoint update/nonaktif akun dan bootstrap Owner terkelola.
- Progres materi end-to-end dan bukti penyelesaian materi.
- Alur evaluasi praktik, persetujuan level, dan riwayat level end-to-end.
- Dashboard statistik, grafik, laporan, ekspor CSV, dan cetak.
- Storage upload/download dengan signed URL dan validasi file.
- RLS/security review melalui project Supabase nyata.
- Browser testing, deployment, dan pengujian integrasi.
- Laporan akhir DOCX/PDF berbasis screenshot aplikasi aktual.

## Pengujian yang dilakukan pada increment ini
Unit test JavaScript untuk enam skenario aturan bisnis berjalan lulus pada lingkungan lokal. Migration SQL belum dijalankan pada project Supabase dan belum diverifikasi oleh PostgreSQL; karena itu hasil pengujian database/RLS masih berstatus belum diuji.


## Pembaruan UI — 17 November 2026
- Landing page mendapat interactive showcase tiga varian produk berbasis ilustrasi CSS, transisi varian, dan navigasi mobile.
- Design system dashboard/login diperbarui dengan palet Kopi Raya dan breakpoint responsif.
- Dashboard Owner, Admin, dan Pegawai memakai navigasi sidebar reusable; tautan modul yang belum memiliki halaman dinonaktifkan agar tidak menjadi broken link.
- Tombol logout ditambahkan pada header dashboard dan tetap memakai handler logout yang sudah tersedia.
- Enam unit test aturan bisnis, pemeriksaan sintaks JavaScript, dan pemeriksaan tautan aset lokal pada halaman yang diperbarui lulus.
- Status tetap belum siap produksi: modul LMS end-to-end, verifikasi Supabase/RLS live, Storage, dan browser testing masih belum selesai.

## Pembaruan implementasi modul LMS — 17 November 2026
- Ditambahkan halaman Owner: manajemen akun Admin, kelola materi, kelola kuis, evaluasi praktik, laporan.
- Ditambahkan halaman Admin: manajemen akun Pegawai.
- Ditambahkan halaman Pegawai: materi, kuis, progres, nilai/riwayat, evaluasi.
- Ditambahkan Netlify Function update-user dan pembatasan role pada create-user.
- Ditambahkan migration workflow untuk simpan kuis/kunci, submit kuis server-side, penilaian, progres, pembukaan ulang kuis, dan bucket Storage privat.
- Status implementasi rinci, konflik dokumen, dan langkah aktivasi tercatat pada `docs/STATUS-PENYELESAIAN-FITUR.md`.
- Kode lolos pemeriksaan sintaks JavaScript dan unit test 6/6. Database migration, Auth, Storage, RLS, deployment, dan browser test live belum diverifikasi.
