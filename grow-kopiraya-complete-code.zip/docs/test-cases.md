# Rencana Pengujian Grow@KopiRaya

| No. | Skenario | Hasil yang diharapkan | Hasil aktual | Status |
|---|---|---|---|---|
| 1 | Login kredensial valid | Dashboard sesuai role | Belum diuji | Belum diuji |
| 2 | Login kredensial salah | Pesan error tanpa membocorkan detail | Belum diuji | Belum diuji |
| 3 | Admin akses endpoint buat akun | Akun dibuat setelah otorisasi Admin | Belum diuji | Belum diuji |
| 4 | Admin membaca nilai kuis | Ditolak oleh RLS | Belum diuji | Belum diuji |
| 5 | Pegawai membaca data pegawai lain | Ditolak oleh RLS | Belum diuji | Belum diuji |
| 6 | Pegawai membuka kuis sebelum materi wajib selesai | Kuis terkunci | Belum diuji | Belum diuji |
| 7 | Praktik kurang dari 14 hari | Level 2 terkunci | Belum diuji | Belum diuji |
| 8 | Praktik minimal 14 hari tanpa rekomendasi Owner | Level 2 tetap terkunci | Belum diuji | Belum diuji |
| 9 | Nilai praktik di luar 0–100 | Ditolak constraint | Belum diuji | Belum diuji |
| 10 | Akses tabel kunci jawaban oleh Pegawai | Ditolak | Belum diuji | Belum diuji |
| 11 | Koneksi database gagal | UI menampilkan error, bukan sukses palsu | Belum diuji | Belum diuji |
| 12 | Tampilan smartphone | Layout responsif | Belum diuji | Belum diuji |
