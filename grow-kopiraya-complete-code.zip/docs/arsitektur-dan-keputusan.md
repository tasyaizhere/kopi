# Grow@KopiRaya — Arsitektur dan Keputusan Implementasi

## Batas sistem
Tepat tiga role: Owner, Admin, Pegawai. Admin hanya mengelola akun. Owner mengelola materi, kuis, evaluasi praktik, keputusan kenaikan level, jadwal evaluasi dan laporan. Pegawai mengikuti pembelajaran dan hanya mengakses data pribadinya.

## Aturan bisnis final
- Praktik Level 2: 14 hari kalender sejak tanggal mulai.
- Kuis dapat diulang sampai lulus; seluruh percobaan disimpan.
- Nilai resmi adalah nilai percobaan terakhir.
- Setelah lulus, percobaan dikunci; Owner dapat membuka kembali untuk evaluasi ulang.
- Semua materi wajib Level 1 harus selesai sebelum kuis Level 1 dibuka.
- Nilai minimum awal 70, dapat dikonfigurasi Owner pada setiap kuis.
- Jadwal evaluasi Level 3 ditentukan Owner, dalam interval 1–3 bulan.

## Arsitektur
Frontend HTML/CSS/JavaScript statis di Netlify. Supabase Auth untuk autentikasi, PostgreSQL dengan RLS untuk data, Storage privat untuk PDF. Netlify Functions digunakan untuk operasi administratif yang memerlukan service role. Service role tidak boleh dikirim ke browser.

## Status implementasi
Kerangka login dan dashboard role disediakan. Migration skema dan contoh policy disediakan sebagai baseline yang harus diuji pada project Supabase baru. Modul penuh, fungsi submit kuis, pengelolaan konten, laporan, dan validasi end-to-end masih perlu dilengkapi dan diuji sebelum aplikasi dinyatakan siap produksi.
