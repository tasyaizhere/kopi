# Status Implementasi Fitur Grow@KopiRaya

Pembaruan implementasi: 17 November 2026.

## Modul yang sudah ditambahkan pada kode

### Owner
- Dashboard statistik pegawai, materi aktif, dan nilai terakhir.
- Daftar pegawai.
- Manajemen akun Admin (buat dan aktif/nonaktifkan melalui backend).
- Kelola materi: tambah, edit, publikasi, arsip/hapus, isi materi, unggah PDF privat.
- Kelola kuis: buat/edit soal pilihan ganda A–D, bobot, kunci, nilai minimum, status publikasi, hapus kuis tanpa riwayat, buka ulang kuis untuk satu percobaan.
- Evaluasi praktik, jadwal Level 3, status penyelesaian jadwal, persetujuan kenaikan level dengan pemeriksaan persyaratan.
- Laporan ringkas per pegawai, ekspor CSV, dan cetak.

### Admin
- Dashboard statistik akun.
- Manajemen akun Pegawai: buat akun, ubah nama/email, aktifkan/nonaktifkan akun.
- Operasi Auth administratif menggunakan Netlify Function dan service role key yang hanya berada di server.

### Pegawai
- Daftar materi yang dapat diakses sesuai level, ringkasan materi, signed URL PDF, tandai selesai.
- Daftar kuis yang terbuka, pengerjaan soal, submit dan penilaian di database.
- Nilai dan riwayat percobaan.
- Ringkasan progres belajar.
- Melihat evaluasi praktik dan jadwal evaluasi.

## Database/backend yang ditambahkan

- `supabase/migrations/002_lms_workflows.sql`: RPC aman untuk simpan kuis beserta kunci, menandai materi selesai, submit/menilai kuis secara server-side, mengambil kuis untuk Owner, membuka ulang kuis; tabel pembukaan ulang; pembatasan write langsung untuk hasil/progres.
- `supabase/migrations/003_storage_setup.sql`: bucket privat `materi-pdf` beserta policies Storage.
- `netlify/functions/update-user.mjs`: update profil dan status Auth pengguna sesuai batas role.
- `create-user.mjs` diperketat: Owner hanya dapat membuat Admin; Admin hanya dapat membuat Pegawai.

## Aturan bisnis yang dijaga

- Tiga role aplikasi: Owner, Admin, Pegawai.
- Level 1: materi wajib harus selesai sebelum kuis Level 1.
- Kuis dihitung di server/database; kunci tidak dikirim ke browser pegawai.
- Nilai resmi berasal dari percobaan terakhir; percobaan dapat diulang sampai lulus.
- Setelah lulus, kuis terkunci sampai Owner membuka ulang satu percobaan.
- Level 2: materi wajib Level 1 selesai, seluruh kuis aktif Level 1 lulus pada percobaan terakhir, praktik minimal 14 hari kalender, dan evaluasi Owner layak/direkomendasikan.
- Level 3: seluruh kuis aktif Level 2 lulus, evaluasi Owner layak/direkomendasikan, jadwal evaluasi selesai, dan persetujuan Owner tercatat.

## Konflik dokumen sumber

Dokumen Analisis Sistem asli menyebut empat aktor (Owner, Admin, Pengawas/Supervisor, Pegawai), dan sebagian alur menyebut Admin mengunggah materi/soal. Master prompt implementasi yang terbaru secara eksplisit menetapkan tiga role (Owner, Admin, Pegawai), Owner mengelola materi/kuis dan Owner melakukan evaluasi. Implementasi mengikuti master prompt terbaru; tidak dibuat role Supervisor baru agar tidak mengubah rancangan role yang sedang dipakai.

## Wajib dilakukan sebelum aplikasi dapat dipakai live

1. Jalankan migration `002_lms_workflows.sql` dan `003_storage_setup.sql` pada project Supabase yang benar, setelah migration awal `001_initial_schema.sql`.
2. Pastikan bucket `materi-pdf` dan policies aktif.
3. Atur environment variables Netlify: `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`. Service role key hanya di Netlify, jangan pernah dimasukkan ke frontend atau repository.
4. Pastikan `js/config.js` memakai URL dan anon/publishable key project Supabase yang sama.
5. Deploy ulang Netlify agar Function baru tersedia.
6. Uji login masing-masing role, CRUD materi/kuis, submit kuis, akun nonaktif, signed URL, evaluasi, dan laporan menggunakan akun uji.

## Status pengujian

- Unit tests aturan bisnis lama: lulus (6/6).
- Pemeriksaan sintaks JavaScript dan Netlify Functions: lulus.
- Pemeriksaan path lokal HTML dan menu: lulus.
- SQL migration: belum dijalankan pada database Supabase live; belum dapat dinyatakan lulus.
- Integrasi Auth/Storage/RLS/Netlify live: belum dapat diuji dari workspace ini karena tidak memiliki akses administratif ke project Supabase/Netlify pengguna.
- Browser/device testing: belum dilakukan.

Karena tiga pemeriksaan terakhir belum dilakukan, status proyek adalah **implementasi kode fitur utama selesai, tetapi belum terverifikasi live dan belum boleh disebut siap produksi**.
