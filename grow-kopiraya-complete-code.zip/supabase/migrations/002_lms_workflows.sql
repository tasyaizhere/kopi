-- Workflow LMS: seluruh operasi penilaian dilakukan di database agar kunci jawaban
-- tidak pernah dikirim ke browser pegawai.

create table if not exists public.kuis_pembukaan_ulang (
  id uuid primary key default gen_random_uuid(),
  pegawai_id uuid not null references public.users(id) on delete cascade,
  kuis_id uuid not null references public.kuis(id) on delete cascade,
  dibuka_oleh uuid not null references public.users(id),
  alasan text not null,
  created_at timestamptz not null default now(),
  unique(pegawai_id, kuis_id)
);
alter table public.kuis_pembukaan_ulang enable row level security;
create policy kuis_reopen_owner_read on public.kuis_pembukaan_ulang for select to authenticated using(public.current_app_role()='owner');
revoke all on public.kuis_pembukaan_ulang from anon, authenticated;

create or replace function public.owner_save_quiz(p_quiz jsonb, p_questions jsonb)
returns uuid language plpgsql security definer set search_path=public as $$
declare v_owner uuid := public.current_user_id(); v_id uuid; q jsonb; v_soal uuid; v_idx int := 0;
begin
 if public.current_app_role() <> 'owner' then raise exception 'Hanya Owner yang dapat mengelola kuis.'; end if;
 if coalesce(jsonb_typeof(p_questions),'') <> 'array' then raise exception 'Format daftar soal tidak valid.'; end if;
 if jsonb_array_length(p_questions) < 1 then raise exception 'Kuis minimal memiliki satu soal.'; end if;
 if coalesce(length(trim(p_quiz->>'nama_kuis')),0) not between 1 and 180 then raise exception 'Nama kuis wajib diisi.'; end if;
 if (p_quiz->>'level')::int not between 1 and 3 then raise exception 'Level kuis tidak valid.'; end if;
 if coalesce((p_quiz->>'nilai_minimum')::numeric,70) not between 0 and 100 then raise exception 'Nilai minimum harus 0 sampai 100.'; end if;
 if nullif(p_quiz->>'id','') is not null then
   v_id := (p_quiz->>'id')::uuid;
   if exists(select 1 from public.hasil_kuis where kuis_id=v_id) then raise exception 'Kuis yang sudah memiliki riwayat pengerjaan tidak dapat diubah. Buat kuis baru agar riwayat tetap akurat.'; end if;
   update public.kuis set nama_kuis=trim(p_quiz->>'nama_kuis'), deskripsi=nullif(trim(p_quiz->>'deskripsi'),''), level=(p_quiz->>'level')::smallint, nilai_minimum=coalesce((p_quiz->>'nilai_minimum')::numeric,70), status=coalesce((p_quiz->>'status')::public.quiz_status,'draft'), updated_at=now() where id=v_id;
   if not found then raise exception 'Kuis tidak ditemukan.'; end if;
   delete from public.soal where kuis_id=v_id;
 else
   insert into public.kuis(nama_kuis,deskripsi,level,nilai_minimum,status,created_by) values(trim(p_quiz->>'nama_kuis'),nullif(trim(p_quiz->>'deskripsi'),''),(p_quiz->>'level')::smallint,coalesce((p_quiz->>'nilai_minimum')::numeric,70),coalesce((p_quiz->>'status')::public.quiz_status,'draft'),v_owner) returning id into v_id;
 end if;
 for q in select value from jsonb_array_elements(p_questions) loop
   v_idx := v_idx + 1;
   if coalesce(length(trim(q->>'pertanyaan')),0)=0 then raise exception 'Pertanyaan nomor % wajib diisi.',v_idx; end if;
   if coalesce(jsonb_typeof(q->'pilihan'),'') <> 'object' or not (q->'pilihan' ? 'A' and q->'pilihan' ? 'B' and q->'pilihan' ? 'C' and q->'pilihan' ? 'D') then raise exception 'Soal % harus memiliki pilihan A sampai D.',v_idx; end if;
   if exists(select 1 from jsonb_each_text(q->'pilihan') as opt(k,v) where trim(coalesce(opt.v,''))='') then raise exception 'Semua pilihan jawaban pada soal % wajib diisi.',v_idx; end if;
   if coalesce(q->>'jawaban_benar','') not in ('A','B','C','D') then raise exception 'Kunci jawaban soal % tidak valid.',v_idx; end if;
   if coalesce((q->>'bobot')::numeric,1) <= 0 then raise exception 'Bobot soal % harus lebih dari nol.',v_idx; end if;
   insert into public.soal(kuis_id,pertanyaan,pilihan,bobot,urutan) values(v_id,trim(q->>'pertanyaan'),q->'pilihan',coalesce((q->>'bobot')::numeric,1),v_idx) returning id into v_soal;
   insert into public.soal_kunci(soal_id,jawaban_benar) values(v_soal,q->>'jawaban_benar');
 end loop;
 return v_id;
end; $$;
revoke all on function public.owner_save_quiz(jsonb,jsonb) from public, anon;
grant execute on function public.owner_save_quiz(jsonb,jsonb) to authenticated;

create or replace function public.complete_material(p_materi_id uuid)
returns void language plpgsql security definer set search_path=public as $$
declare v_user uuid := public.current_user_id(); v_level smallint;
begin
 if public.current_app_role() <> 'pegawai' then raise exception 'Hanya pegawai yang dapat menandai materi.'; end if;
 select level into v_level from public.materi where id=p_materi_id and status_publikasi='publikasi';
 if v_level is null or not public.can_access_level(v_level) then raise exception 'Materi belum dapat diakses.'; end if;
 insert into public.progres_materi(pegawai_id,materi_id,status,tanggal_mulai,tanggal_selesai) values(v_user,p_materi_id,'selesai',now(),now())
 on conflict(pegawai_id,materi_id) do update set status='selesai', tanggal_mulai=coalesce(public.progres_materi.tanggal_mulai,now()), tanggal_selesai=now();
end; $$;
revoke all on function public.complete_material(uuid) from public, anon;
grant execute on function public.complete_material(uuid) to authenticated;

create or replace function public.submit_quiz(p_kuis_id uuid, p_answers jsonb)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_user uuid := public.current_user_id(); v_quiz public.kuis%rowtype; v_attempt int; v_score numeric(5,2); v_total numeric; v_correct numeric; v_result uuid; v_pass boolean; v_count int;
begin
 if public.current_app_role() <> 'pegawai' then raise exception 'Hanya pegawai yang dapat mengerjakan kuis.'; end if;
 select * into v_quiz from public.kuis where id=p_kuis_id and status='aktif' for update;
 if not found or not public.can_access_quiz(p_kuis_id) then raise exception 'Kuis belum dapat diakses.'; end if;
 if coalesce(jsonb_typeof(p_answers),'') <> 'object' then raise exception 'Format jawaban tidak valid.'; end if;
 if exists(select 1 from public.hasil_kuis h where h.pegawai_id=v_user and h.kuis_id=p_kuis_id and h.status_kelulusan)
    and not exists(select 1 from public.kuis_pembukaan_ulang r where r.pegawai_id=v_user and r.kuis_id=p_kuis_id) then raise exception 'Kuis sudah lulus dan terkunci.'; end if;
 select count(*),coalesce(sum(s.bobot),0),coalesce(sum(case when k.jawaban_benar = upper(p_answers->>s.id::text) then s.bobot else 0 end),0)
 into v_count,v_total,v_correct from public.soal s join public.soal_kunci k on k.soal_id=s.id where s.kuis_id=p_kuis_id;
 if v_count=0 or (select count(*) from jsonb_object_keys(p_answers)) <> v_count then raise exception 'Semua soal wajib dijawab.'; end if;
 if exists(select 1 from public.soal s where s.kuis_id=p_kuis_id and not (p_answers ? s.id::text)) then raise exception 'Semua soal wajib dijawab.'; end if;
 if exists(select 1 from jsonb_object_keys(p_answers) as keys(key) where not exists(select 1 from public.soal s where s.kuis_id=p_kuis_id and s.id::text=keys.key)) then raise exception 'Terdapat jawaban dari soal yang tidak sesuai.'; end if;
 if exists(select 1 from public.soal s where s.kuis_id=p_kuis_id and upper(coalesce(p_answers->>s.id::text,'')) not in ('A','B','C','D')) then raise exception 'Terdapat jawaban yang tidak valid.'; end if;
 perform pg_advisory_xact_lock(hashtextextended(v_user::text || p_kuis_id::text,0));
 select coalesce(max(percobaan_ke),0)+1 into v_attempt from public.hasil_kuis where pegawai_id=v_user and kuis_id=p_kuis_id;
 v_score := round((v_correct/nullif(v_total,0))*100,2); v_pass := v_score >= v_quiz.nilai_minimum;
 insert into public.hasil_kuis(pegawai_id,kuis_id,percobaan_ke,nilai,status_kelulusan) values(v_user,p_kuis_id,v_attempt,v_score,v_pass) returning id into v_result;
 insert into public.jawaban_pegawai(hasil_kuis_id,soal_id,jawaban,benar)
 select v_result,s.id,upper(p_answers->>s.id::text),k.jawaban_benar=upper(p_answers->>s.id::text) from public.soal s join public.soal_kunci k on k.soal_id=s.id where s.kuis_id=p_kuis_id;
 if exists(select 1 from public.kuis_pembukaan_ulang r where r.pegawai_id=v_user and r.kuis_id=p_kuis_id) then delete from public.kuis_pembukaan_ulang where pegawai_id=v_user and kuis_id=p_kuis_id; end if;
 return jsonb_build_object('hasil_id',v_result,'percobaan_ke',v_attempt,'nilai',v_score,'lulus',v_pass,'nilai_minimum',v_quiz.nilai_minimum);
end; $$;
revoke all on function public.submit_quiz(uuid,jsonb) from public, anon;
grant execute on function public.submit_quiz(uuid,jsonb) to authenticated;

create or replace function public.owner_reopen_quiz(p_pegawai_id uuid,p_kuis_id uuid,p_alasan text)
returns void language plpgsql security definer set search_path=public as $$
begin
 if public.current_app_role() <> 'owner' then raise exception 'Hanya Owner yang dapat membuka ulang kuis.'; end if;
 if length(trim(coalesce(p_alasan,''))) < 5 then raise exception 'Alasan pembukaan ulang wajib diisi.'; end if;
 if not exists(select 1 from public.users where id=p_pegawai_id and role='pegawai') or not exists(select 1 from public.kuis where id=p_kuis_id) then raise exception 'Pegawai atau kuis tidak ditemukan.'; end if;
 insert into public.kuis_pembukaan_ulang(pegawai_id,kuis_id,dibuka_oleh,alasan) values(p_pegawai_id,p_kuis_id,public.current_user_id(),trim(p_alasan))
 on conflict(pegawai_id,kuis_id) do update set dibuka_oleh=excluded.dibuka_oleh,alasan=excluded.alasan,created_at=now();
end; $$;
revoke all on function public.owner_reopen_quiz(uuid,uuid,text) from public, anon;
grant execute on function public.owner_reopen_quiz(uuid,uuid,text) to authenticated;

-- RLS tambahan: progres/hasil hanya ditulis melalui RPC SECURITY DEFINER.
revoke insert, update, delete on public.progres_materi, public.hasil_kuis, public.jawaban_pegawai from anon, authenticated;

create or replace function public.owner_get_quiz(p_kuis_id uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_result jsonb;
begin
 if public.current_app_role() <> 'owner' then raise exception 'Hanya Owner yang dapat melihat kunci jawaban.'; end if;
 select jsonb_build_object('id',k.id,'nama_kuis',k.nama_kuis,'deskripsi',k.deskripsi,'level',k.level,'nilai_minimum',k.nilai_minimum,'status',k.status,
   'soal',coalesce((select jsonb_agg(jsonb_build_object('id',s.id,'pertanyaan',s.pertanyaan,'pilihan',s.pilihan,'bobot',s.bobot,'urutan',s.urutan,'jawaban_benar',sk.jawaban_benar) order by s.urutan) from public.soal s join public.soal_kunci sk on sk.soal_id=s.id where s.kuis_id=k.id),'[]'::jsonb))
 into v_result from public.kuis k where k.id=p_kuis_id;
 if v_result is null then raise exception 'Kuis tidak ditemukan.'; end if;
 return v_result;
end; $$;
revoke all on function public.owner_get_quiz(uuid) from public, anon;
grant execute on function public.owner_get_quiz(uuid) to authenticated;

-- Batasi visibilitas Admin pada daftar Pegawai. Profil Admin sendiri tetap
-- dapat dibaca melalui policy users_self_read.
drop policy if exists users_admin_read on public.users;
create policy users_admin_read on public.users
for select to authenticated
using(public.current_app_role()='admin' and role='pegawai');
