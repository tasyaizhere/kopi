-- Bucket materi bersifat privat. File hanya diakses melalui signed URL.
insert into storage.buckets(id,name,public)
values('materi-pdf','materi-pdf',false)
on conflict(id) do update set public=false;

drop policy if exists "owner upload materi" on storage.objects;
drop policy if exists "owner update materi" on storage.objects;
drop policy if exists "owner delete materi" on storage.objects;
drop policy if exists "authorized read materi" on storage.objects;

create policy "owner upload materi" on storage.objects
for insert to authenticated
with check(bucket_id='materi-pdf' and public.current_app_role()='owner');

create policy "owner update materi" on storage.objects
for update to authenticated
using(bucket_id='materi-pdf' and public.current_app_role()='owner')
with check(bucket_id='materi-pdf' and public.current_app_role()='owner');

create policy "owner delete materi" on storage.objects
for delete to authenticated
using(bucket_id='materi-pdf' and public.current_app_role()='owner');

create policy "authorized read materi" on storage.objects
for select to authenticated
using(bucket_id='materi-pdf' and (
 public.current_app_role()='owner'
 or (public.current_app_role()='pegawai' and exists(
   select 1 from public.materi m
   where m.file_path=storage.objects.name
     and m.status_publikasi='publikasi'
     and public.can_access_level(m.level)
 ))
));
