create extension if not exists pgcrypto;
create type public.app_role as enum ('owner','admin','pegawai');
create type public.account_status as enum ('aktif','nonaktif');
create type public.learning_status as enum ('belum','sedang','selesai');
create type public.quiz_status as enum ('draft','aktif','nonaktif');

create table public.users (
 id uuid primary key default gen_random_uuid(), auth_user_id uuid unique not null references auth.users(id) on delete cascade,
 nama varchar(120) not null, email varchar(255) not null unique, role public.app_role not null,
 status_akun public.account_status not null default 'aktif', created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.materi (
 id uuid primary key default gen_random_uuid(), judul varchar(180) not null, deskripsi text, isi_materi text,
 level smallint not null check(level between 1 and 3), file_path text, wajib boolean not null default true,
 status_publikasi varchar(20) not null default 'draft' check(status_publikasi in ('draft','publikasi','arsip')),
 created_by uuid not null references public.users(id), created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.kuis (
 id uuid primary key default gen_random_uuid(), nama_kuis varchar(180) not null, deskripsi text,
 level smallint not null check(level between 1 and 3), nilai_minimum numeric(5,2) not null default 70 check(nilai_minimum between 0 and 100),
 status public.quiz_status not null default 'draft', created_by uuid not null references public.users(id), created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.soal (
 id uuid primary key default gen_random_uuid(), kuis_id uuid not null references public.kuis(id) on delete cascade,
 pertanyaan text not null, pilihan jsonb not null check(jsonb_typeof(pilihan)='object'),
 bobot numeric(8,2) not null default 1 check(bobot>0), urutan integer not null default 1, created_at timestamptz not null default now()
);
create table public.soal_kunci (
 soal_id uuid primary key references public.soal(id) on delete cascade, jawaban_benar varchar(1) not null check(jawaban_benar in ('A','B','C','D','E')),
 updated_at timestamptz not null default now()
);
create table public.progres_materi (
 id uuid primary key default gen_random_uuid(), pegawai_id uuid not null references public.users(id), materi_id uuid not null references public.materi(id),
 status public.learning_status not null default 'belum', tanggal_mulai timestamptz, tanggal_selesai timestamptz, unique(pegawai_id,materi_id)
);
create table public.hasil_kuis (
 id uuid primary key default gen_random_uuid(), pegawai_id uuid not null references public.users(id), kuis_id uuid not null references public.kuis(id),
 percobaan_ke integer not null check(percobaan_ke>0), nilai numeric(5,2) not null check(nilai between 0 and 100), status_kelulusan boolean not null,
 tanggal_mulai timestamptz not null default now(), tanggal_selesai timestamptz not null default now(), unique(pegawai_id,kuis_id,percobaan_ke)
);
create table public.jawaban_pegawai (
 id uuid primary key default gen_random_uuid(), hasil_kuis_id uuid not null references public.hasil_kuis(id) on delete cascade,
 soal_id uuid not null references public.soal(id), jawaban varchar(1) check(jawaban in ('A','B','C','D','E')), benar boolean not null, unique(hasil_kuis_id,soal_id)
);
create table public.evaluasi_praktik (
 id uuid primary key default gen_random_uuid(), pegawai_id uuid not null references public.users(id), owner_id uuid not null references public.users(id),
 tanggal_mulai date not null, tanggal_evaluasi date, nilai_praktik numeric(5,2) check(nilai_praktik between 0 and 100), catatan text,
 rekomendasi varchar(24) not null default 'belum_direkomendasikan' check(rekomendasi in ('direkomendasikan','tidak_direkomendasikan','belum_direkomendasikan')),
 status_kelayakan varchar(20) not null default 'menunggu' check(status_kelayakan in ('layak','belum_layak','menunggu')),
 created_at timestamptz not null default now(), updated_at timestamptz not null default now(), check(tanggal_evaluasi is null or tanggal_evaluasi >= tanggal_mulai)
);
create table public.riwayat_level (
 id uuid primary key default gen_random_uuid(), pegawai_id uuid not null references public.users(id), level_sebelumnya smallint not null check(level_sebelumnya between 1 and 3),
 level_baru smallint not null check(level_baru between 1 and 3), tanggal_perubahan timestamptz not null default now(), disetujui_oleh uuid not null references public.users(id), alasan text not null,
 check(level_baru=level_sebelumnya+1)
);
create table public.jadwal_evaluasi (
 id uuid primary key default gen_random_uuid(), pegawai_id uuid not null references public.users(id), owner_id uuid not null references public.users(id),
 level smallint not null default 3 check(level=3), tanggal_evaluasi date not null, status varchar(20) not null default 'terjadwal' check(status in ('terjadwal','selesai','dibatalkan')),
 catatan text, created_at timestamptz not null default now()
);
create table public.audit_logs (
 id uuid primary key default gen_random_uuid(), actor_id uuid references public.users(id), tindakan varchar(80) not null, nama_tabel varchar(80) not null,
 record_id uuid, data_perubahan jsonb, created_at timestamptz not null default now()
);
create index idx_materi_level_status on public.materi(level,status_publikasi);
create index idx_kuis_level_status on public.kuis(level,status);
create index idx_hasil_pegawai_kuis_date on public.hasil_kuis(pegawai_id,kuis_id,tanggal_selesai desc);
create index idx_progres_pegawai on public.progres_materi(pegawai_id,status);
create index idx_evaluasi_pegawai on public.evaluasi_praktik(pegawai_id,tanggal_mulai desc);
create index idx_jadwal_pegawai_date on public.jadwal_evaluasi(pegawai_id,tanggal_evaluasi);

create or replace function public.current_app_role() returns public.app_role language sql stable security definer set search_path=public as $$ select role from public.users where auth_user_id=auth.uid() and status_akun='aktif' limit 1 $$;
create or replace function public.current_user_id() returns uuid language sql stable security definer set search_path=public as $$ select id from public.users where auth_user_id=auth.uid() and status_akun='aktif' limit 1 $$;
create or replace function public.can_access_level(target_level smallint) returns boolean language sql stable security definer set search_path=public as $$
 select case when public.current_app_role()='owner' then true when public.current_app_role()<>'pegawai' then false
 when target_level=1 then true
 when target_level=2 then exists(select 1 from public.kuis k where k.level=1 and k.status='aktif') and not exists(select 1 from public.kuis k where k.level=1 and k.status='aktif' and not exists(select 1 from public.hasil_kuis h where h.pegawai_id=public.current_user_id() and h.kuis_id=k.id and h.id=(select h2.id from public.hasil_kuis h2 where h2.pegawai_id=h.pegawai_id and h2.kuis_id=h.kuis_id order by h2.percobaan_ke desc limit 1) and h.status_kelulusan)) and exists(select 1 from public.evaluasi_praktik e where e.pegawai_id=public.current_user_id() and e.status_kelayakan='layak' and e.rekomendasi='direkomendasikan' and current_date-e.tanggal_mulai>=14)
 when target_level=3 then exists(select 1 from public.riwayat_level r where r.pegawai_id=public.current_user_id() and r.level_baru=3) else false end $$;
create or replace function public.can_access_quiz(target_quiz uuid) returns boolean language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.kuis k where k.id=target_quiz and public.can_access_level(k.level) and (k.level<>1 or not exists(select 1 from public.materi m where m.level=1 and m.wajib and m.status_publikasi='publikasi' and not exists(select 1 from public.progres_materi p where p.materi_id=m.id and p.pegawai_id=public.current_user_id() and p.status='selesai')))) $$;

alter table public.users enable row level security;
alter table public.materi enable row level security;
alter table public.kuis enable row level security;
alter table public.soal enable row level security;
alter table public.soal_kunci enable row level security;
alter table public.progres_materi enable row level security;
alter table public.hasil_kuis enable row level security;
alter table public.jawaban_pegawai enable row level security;
alter table public.evaluasi_praktik enable row level security;
alter table public.riwayat_level enable row level security;
alter table public.jadwal_evaluasi enable row level security;
alter table public.audit_logs enable row level security;

create policy users_owner_read on public.users for select to authenticated using(public.current_app_role()='owner');
create policy users_admin_read on public.users for select to authenticated using(public.current_app_role()='admin');
create policy users_self_read on public.users for select to authenticated using(auth_user_id=auth.uid());
create policy materi_owner_all on public.materi for all to authenticated using(public.current_app_role()='owner') with check(public.current_app_role()='owner');
create policy materi_pegawai_read on public.materi for select to authenticated using(public.current_app_role()='pegawai' and status_publikasi='publikasi' and public.can_access_level(level));
create policy kuis_owner_all on public.kuis for all to authenticated using(public.current_app_role()='owner') with check(public.current_app_role()='owner');
create policy kuis_pegawai_read on public.kuis for select to authenticated using(public.current_app_role()='pegawai' and status='aktif' and public.can_access_quiz(id));
create policy soal_owner_all on public.soal for all to authenticated using(public.current_app_role()='owner') with check(public.current_app_role()='owner');
create policy soal_pegawai_read on public.soal for select to authenticated using(public.current_app_role()='pegawai' and exists(select 1 from public.kuis k where k.id=kuis_id and k.status='aktif' and public.can_access_quiz(k.id)));
create policy soal_kunci_owner_all on public.soal_kunci for all to authenticated using(public.current_app_role()='owner') with check(public.current_app_role()='owner');
revoke all on public.soal_kunci from anon, authenticated;
create policy progres_owner_read on public.progres_materi for select to authenticated using(public.current_app_role()='owner');
create policy progres_self_read on public.progres_materi for select to authenticated using(pegawai_id=public.current_user_id());
create policy hasil_owner_read on public.hasil_kuis for select to authenticated using(public.current_app_role()='owner');
create policy hasil_self_read on public.hasil_kuis for select to authenticated using(pegawai_id=public.current_user_id());
create policy jawaban_owner_read on public.jawaban_pegawai for select to authenticated using(public.current_app_role()='owner');
create policy jawaban_self_read on public.jawaban_pegawai for select to authenticated using(exists(select 1 from public.hasil_kuis h where h.id=hasil_kuis_id and h.pegawai_id=public.current_user_id()));
create policy evaluasi_owner_all on public.evaluasi_praktik for all to authenticated using(public.current_app_role()='owner') with check(public.current_app_role()='owner');
create policy evaluasi_self_read on public.evaluasi_praktik for select to authenticated using(pegawai_id=public.current_user_id());
create policy level_owner_all on public.riwayat_level for all to authenticated using(public.current_app_role()='owner') with check(public.current_app_role()='owner');
create policy level_self_read on public.riwayat_level for select to authenticated using(pegawai_id=public.current_user_id());
create policy jadwal_owner_all on public.jadwal_evaluasi for all to authenticated using(public.current_app_role()='owner') with check(public.current_app_role()='owner');
create policy jadwal_self_read on public.jadwal_evaluasi for select to authenticated using(pegawai_id=public.current_user_id());
create policy audit_owner_read on public.audit_logs for select to authenticated using(public.current_app_role()='owner');

-- Kunci jawaban dipisahkan ke soal_kunci; role pegawai tidak memiliki privilege baca tabel tersebut. Untuk aplikasi produksi,
-- endpoint submit harus berupa fungsi SECURITY DEFINER/backend tepercaya yang mengambil kunci,
-- menghitung skor, menyimpan percobaan dan jawaban dalam satu transaksi.
